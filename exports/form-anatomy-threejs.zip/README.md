# FORM — Anatomy in motion

Run `npm start` (Node.js 22+) and open http://127.0.0.1:4173/three/. All browser dependencies are included locally. The original SVG gallery is available at http://127.0.0.1:4173/.

See [the 3D prompts and source](three/README.md), [anatomy sources](three/SOURCES.md), and [review evidence](qa/three/art-review.json). No MP4 files are included.
