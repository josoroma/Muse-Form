# FORM + MUSE — Anatomy and expression

Run `npm start` (Node.js 22+) and open http://127.0.0.1:4173/expressions/ for MUSE or http://127.0.0.1:4173/three/ for FORM. All browser dependencies are included locally. The original SVG gallery is available at http://127.0.0.1:4173/.

See [the anatomy prompts and source](three/README.md), [facial-expression prompts](expressions/README.md), [anatomy review](qa/three/art-review.json), and [portrait review](qa/expressions/art-review.json). No MP4 files are included.
